function myfunction(){
    var elem = document.getElementById("elimina");
  elem.parentNode.removeChild(elem);}
function myfunction1() {
  var elem = document.getElementById("elimina1");
  elem.parentNode.removeChild(elem);}