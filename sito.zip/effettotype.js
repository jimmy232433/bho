var i = 0;
var txt = 'Benvenuto';
var speed = 50;

document.getElementById("demo").innerHTML += txt.charAt(i);
i++;
setTimeout(typeWriter, speed);
typeWriter()
